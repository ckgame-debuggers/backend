node scripts/check-env.js && pm2 delete all && pm2 start dist/main.js
