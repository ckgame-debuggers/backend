export interface JwtPayload {
  id: number;
  username: string;
  email: string;
  schoolNumber: string;
}
