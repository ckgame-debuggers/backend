export class Oauth2JwtPayload {
  user_id: number;
  app_id: string;
}
