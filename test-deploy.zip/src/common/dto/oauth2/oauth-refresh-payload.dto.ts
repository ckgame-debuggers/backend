export class Oauth2RefreshPayload {
  user_id: number;
  client_id: string;
}
